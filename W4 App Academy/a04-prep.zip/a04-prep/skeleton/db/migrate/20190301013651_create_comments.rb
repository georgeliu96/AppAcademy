class CreateComments < ActiveRecord::Migration[5.1]
  def change
    create_table :comments do |t|
      t.text :body, null: false 
      t.integer :user, null: false 
      t.integer :link, null: false 
    end
    add_index :comments, :user 
    add_index :comments, :link
  end
end
