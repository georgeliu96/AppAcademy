class Comment < ApplicationRecord 

  validates :body, :user, :link, presence: true 

  belongs_to :user,
    class_name: :User,
    foreign_key: :user 

  belongs_to :link,
    class_name: :Link,
    foreign_key: :link

end 