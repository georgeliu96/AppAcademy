class Link < ApplicationRecord 

  validates :title, :url, :user, presence: true 

  belongs_to :user,
    class_name: :User,
    foreign_key: :user 

  has_many :comments,
    class_name: :Comment,
    foreign_key: :user 

end 